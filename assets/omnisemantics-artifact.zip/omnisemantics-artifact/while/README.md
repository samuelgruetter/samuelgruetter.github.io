# Coq formalization of a "Pair Heapification" compiler pass

The file `PairHeapification.v` has no dependencies and was tested with Coq 8.15.1 and Coq 8.16.0.
