#############################################################
# Main files

  - Omnisemantics.v
    All results from section 2, 3 and 5.
    (This file generalizes results that have appeared previously
    in the "Separation Logic Foundations" course.)

  - Omnityping.v
    Results from section 4, using locally nameless style.
    (This file uses the locally nameless representation, it is
    adapted from the `STLC_Ref_*.v` files associated from:
    https://github.com/charguer/formalmetacoq/tree/master/ln )


#############################################################
# Usage

The theories compile with Coq 8.15.

Just run `make` to compile the libraries and files.

To play the files in CoqIDE, execute:

```
   coqide -async-proofs off -async-proofs-command-error-resilience off -Q . DEV CPS*.v
```

Remark: the options provided to CoqIDE makes its use much smoother.



#############################################################
# Auxiliary files

  - Files LibSep*.v
    Local copy of files from the files associated with the paper
    Separation Logic for Sequential Programs (ICFP'20),
    available from: http://www.chargueraud.org/teach/verif/

  - Other files Lib*.v
    Local copy of the TLC library: https://github.com/charguer/tlc
    which is used in particular by the locally nameless library.


