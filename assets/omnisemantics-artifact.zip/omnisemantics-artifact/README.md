# Code Supplement for Omnisemantics: Smoother Handling of Nondeterminism

Contents:

- `./lambda`: Coq formalization of sections 2-5, see separate README there.
- `./while`: Coq formalization of the "pair heapification" compiler pass from section 6.
- `./bedrock2.zip`: Larger Coq development containing a compiler pass for stack allocation and code generation as described in section 6 (`compiler/src/compiler/FlatToRiscvFunctions.v`) and a frame rule proof (`bedrock2/src/bedrock2/FrameRule.v`). The code is a snapshot of `https://github.com/mit-plv/bedrock2` and is further described in the PLDI'21 paper "Integration Verification Across Software and Hardware for a Simple Embedded System" as referenced in the paper. It requires Coq 8.16.0.
